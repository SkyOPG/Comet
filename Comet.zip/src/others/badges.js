module.exports = {
    skull: "https://cdn.discordapp.com/attachments/1081881878304395374/1109253298021744660/skull.png",
    dev: "https://cdn.discordapp.com/attachments/1081881878304395374/1109424148196884520/7088-early-verified-bot-developer.png",
    partner: "https://cdn.discordapp.com/attachments/1081881878304395374/1109424214366244864/5477-partnered-server-owner.png"
}