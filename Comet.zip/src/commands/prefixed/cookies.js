module.exports = {
    category: "fun",
    data: {
        name: "cookies",
        aliases: ["cookie"]
    },
    execute(_client, message, _args){
        message.reply('🍪')
    }
}