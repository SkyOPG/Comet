We are currently allowing security updates!

| Current Version  | :white_check_mark: |


## Reporting a Vulnerability

Report a vulnerability in the discord!
